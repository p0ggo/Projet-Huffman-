var searchData=
[
  ['r_5fs_5fdico_28',['r_s_dico',['../read__txt_8h.html#a88e43a0b56ddd9ae7ed560c7773b3e28',1,'read_txt.c']]],
  ['random_2eh_29',['random.h',['../random_8h.html',1,'']]],
  ['read_5ftxt_30',['read_txt',['../read__txt_8h.html#aebd88dfebe3ed57ccc83ceca43f34c09',1,'read_txt.c']]],
  ['read_5ftxt_2eh_31',['read_txt.h',['../read__txt_8h.html',1,'']]],
  ['rst_5fdico_32',['rst_dico',['../write__txt_8c.html#abb9341d9d2a57fad28c4a82949f4b6d1',1,'write_txt.c']]]
];
