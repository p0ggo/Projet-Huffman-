var searchData=
[
  ['dictionary_47',['Dictionary',['../struct_dictionary.html',1,'']]]
];
