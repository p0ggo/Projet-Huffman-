var searchData=
[
  ['letter_94',['Letter',['../struct_8h.html#aaa534a3a71c0c409b8d0703b79adb7b1',1,'struct.h']]],
  ['list_5fchar_95',['List_char',['../struct_8h.html#a479b596f432bb58a9d92a72d943bd49b',1,'struct.h']]]
];
