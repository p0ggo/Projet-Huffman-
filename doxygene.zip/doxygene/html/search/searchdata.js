var indexSectionsWithContent =
{
  0: "acdehlmnpqrstw",
  1: "delnqt",
  2: "dlnrstw",
  3: "acdhlmnrstw",
  4: "dlnt",
  5: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "typedefs",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Typedefs",
  5: "Pages"
};

