var searchData=
[
  ['node_5fin_5ftree_79',['node_in_tree',['../tree_8h.html#aab00330aac23dfa0b00c172d73be9721',1,'tree.c']]]
];
