var searchData=
[
  ['write_5ftxt_2ec_61',['write_txt.c',['../write__txt_8c.html',1,'']]]
];
